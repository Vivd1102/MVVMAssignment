
//

import Foundation
import UIKit

protocol UserServiceProtocol {
    
//    func doLogin(email: String, password:String, completion:@escaping (Result<Any>) -> Void)
    
    func dofectlisting(pagenum: Int,limit: Int, completion:@escaping ([NSDictionary]?) -> Void)
}

public class UserService: APIService, UserServiceProtocol {
    
//    func doLogin(email: String, password:String, completion:@escaping (Result<Any>) -> Void) {
//
////        let param = [Keys.email:email, Keys.password : password]
////
////        super.startService(with: .POST, path: Config.login, parameters: param, files: [], modelType: User) { (result) in
////            DispatchQueue.main.async {
////                switch result {
////                case .Success(let data):
////                    // Parse Here
////                    completion(.Success(data))
////                case .Error(let message):
////                    completion(.Error(message))
////                }
////            }
////        }
//    }
    
    
    func dofectlisting(pagenum: Int, limit: Int, completion: @escaping ([NSDictionary]?) -> Void) {
        
        guard let url = URL(string: "https://5e99a9b1bc561b0016af3540.mockapi.io/jet2/api/v1/blogs?page=\(pagenum)&limit=\(limit)") else {
            print("Error unwrapping URL"); return }
        
        //4 - create a session and dataTask on that session to get data/response/error
        let session = URLSession.shared
        let dataTask = session.dataTask(with: url) { (data, response, error) in
            
            //5 - unwrap our returned data
            guard let unwrappedData = data else { print("Error getting data"); return }
            
            do {
                //6 - create an object for our JSON data and cast it as a NSDictionary
                // .allowFragments specifies that the json parser should allow top-level objects that aren't NSArrays or NSDictionaries.
                if let responseJSON = try JSONSerialization.jsonObject(with: unwrappedData, options: .allowFragments) as? Any {
                    
                    //7 - create an array of dictionaries from
//                    let json = responseJSON
                    completion(responseJSON as? [NSDictionary])
                }
            } catch {
                //9 - if we have an error, set our completion with nil
                completion(nil)
                print("Error getting API data: \(error.localizedDescription)")
            }
        }
        //10 -
        dataTask.resume()
        
        
    }
}

