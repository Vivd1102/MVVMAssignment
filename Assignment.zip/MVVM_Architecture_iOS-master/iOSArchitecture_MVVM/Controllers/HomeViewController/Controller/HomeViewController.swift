//
//  HomeViewController.swift
//  FantomLED
//
//  Created by Surjeet Singh on 01/06/18.
//  Copyright © 2018 Surjeet Singh. All rights reserved.
//

import UIKit
import SDWebImage
import MaterialActivityIndicator

class HomeViewController: BaseViewController {
    
    @IBOutlet weak var tblView: UITableView?
    private let indicator = MaterialActivityIndicatorView()

    var pagenum : Int = 0
    var limit : Int = 10
    var isLoading = false
    
    lazy var viewModel: HomeViewModel = {
        let obj = HomeViewModel(userService: UserService())
        self.baseVwModel = obj
        return obj
    }()
    
    
    // MARK:// Apple Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupActivityIndicatorView()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.initialize()
        self.hideBackButton()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        indicator.startAnimating()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        indicator.stopAnimating()
    }
    func initialize() {

//        self.tblView?.register(UINib(nibName: CustomSliderTableCell.className, bundle: nil), forCellReuseIdentifier: CustomSliderTableCell.className)
     
        self.title = "Articles"
        self.navigationController?.navigationBar.backgroundColor = .gray
        
        self.tblView?.tableFooterView = UIView()
        
        self.initViewModel()
        
    }
       
    func initViewModel() {
        
        viewModel.reloadListViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                self?.indicator.stopAnimating()
                self?.tblView?.reloadData()
            }
        }

        viewModel.fetchListing(pagenum:pagenum,limit:limit)
    }
    
}

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRow(section)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return viewModel.heightForIndexPath(indexPath) //(obj.status ? 138 : 110)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: TableCell.className, for: indexPath) as? TableCell else {
            return UITableViewCell()
        }
        cell.listing = viewModel.roomForIndexPath(indexPath)
        
        
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        if (offsetY > contentHeight - scrollView.frame.height * 4)  && !isLoading {
            loadMoreData()
        }
    }
    
    func loadMoreData() {
        if !self.isLoading {
            self.isLoading = true
            DispatchQueue.global().async {
                // Fake background loading task for 2 seconds
                sleep(2)
                // Download more data here
                DispatchQueue.main.async {
                    self.isLoading = false
                    self.pagenum = self.pagenum + 1
//                    self.limit = self.limit + 10
                    self.viewModel.fetchListing(pagenum:self.pagenum,limit:self.limit)
                }
            }
        }
    }

//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let controller = self.storyboard?.instantiateViewController(withIdentifier: DetailViewController.className) as! DetailViewController
//        controller.viewModel = DetailViewModel(with: viewModel.roomForIndexPath(indexPath))
//        self.navigationController?.pushViewController(controller, animated: true)
//    }
}

class TableCell:UITableViewCell {
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var subTitleLbl: UILabel!
    
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var imgContent: UIImageView!
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var lblLikes: UILabel!
    @IBOutlet weak var lblComments: UILabel!
    
    open var listing:Base? {
        didSet {
            
            self.imgProfile.layer.borderWidth=1.0
            self.imgProfile.layer.masksToBounds = false
//            self.imgProfile.layer.borderColor = (UIColor.white as! CGColor)
            self.imgProfile.layer.cornerRadius = self.imgProfile.frame.size.height/2
            self.imgProfile.clipsToBounds = true
            
            
            self.subTitleLbl.text = listing?.content
            self.lblLikes.text = "\(listing?.likes ?? 0) Likes"
            self.lblComments.text = "\(listing?.comments ?? 0 ) Comments"
            let userobj = listing?.user ?? []
            for obj in userobj{
                self.titleLbl.text = obj.name
                self.lblDesignation.text = obj.designation
                self.imgProfile.sd_setImage(with: URL(string: (obj.avatar ?? "")), placeholderImage: UIImage(named: ""))
            }
            let mediaobj = listing?.media ?? []
            for obj in mediaobj{
                self.imgContent.sd_setImage(with: URL(string: (obj.image ?? "")), placeholderImage: UIImage(named: ""))
            }
            
//            self.titleLbl.text =
            
//            self.contentView.backgroundColor = (listing?.enable ?? false) ? UIColor.white : UIColor.lightGray.withAlphaComponent(0.3)
        }
    }
    

}


extension HomeViewController{
    private func setupActivityIndicatorView() {
        view.addSubview(indicator)
        setupActivityIndicatorViewConstraints()
    }

    private func setupActivityIndicatorViewConstraints() {
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        indicator.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}
