
//
// Use this class for storing shared instances

import Foundation

class AppInstance: NSObject {
   
    static let shared = AppInstance()
    var user:User?
    var authToken:String?
    
    override init() {
        super.init()
    }
}
