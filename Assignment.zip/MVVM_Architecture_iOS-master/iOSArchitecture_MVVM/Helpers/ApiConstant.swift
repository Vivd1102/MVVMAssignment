
//

import UIKit

enum Config {
    
    // Copy base url here
    
    #if DEVELOPMENT
    static let BASE_URL:String = "https://5e99a9b1bc561b0016af3540.mockapi.io/"
    #else
    static let BASE_URL:String = "https://5e99a9b1bc561b0016af3540.mockapi.io/"
    #endif
    
    // All end points will be here
    static let login = "/jet2/api/v1/blogs?page=1&limit=10"
    static let Home = "jet2/api/v1/blogs?page=1&limit=10"
    
}


enum Keys {
    static let email    = "email"
    static let password = "password"
    static let page = "page"
    static let limit = "limit"

}
